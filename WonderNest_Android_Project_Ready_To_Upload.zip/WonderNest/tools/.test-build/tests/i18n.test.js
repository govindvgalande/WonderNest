"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const i18n_1 = require("../src/content/i18n");
const catalog_1 = require("../src/core/catalog");
(0, node_test_1.test)('Three text catalogs have identical keys and nonempty translations', () => {
    const reference = Object.keys(i18n_1.translations.en).sort();
    for (const locale of ['en', 'hi', 'mr']) {
        strict_1.default.deepEqual(Object.keys(i18n_1.translations[locale]).sort(), reference);
        for (const [k, v] of Object.entries(i18n_1.translations[locale]))
            strict_1.default.ok(v.trim(), `${locale}:${k}`);
        for (const id of [...catalog_1.OBJECTS, ...catalog_1.SHAPES, ...catalog_1.NOTES, ...catalog_1.PLACES])
            strict_1.default.notEqual((0, i18n_1.tokenName)(locale, id), id, `${locale}/${id}`);
        strict_1.default.ok((0, i18n_1.t)(locale, 'questionObserve', { item: 'TEST' }).includes('TEST'));
    }
});
