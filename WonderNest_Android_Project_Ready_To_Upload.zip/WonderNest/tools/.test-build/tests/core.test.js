"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const generate_1 = require("../src/core/generate");
const adaptive_1 = require("../src/core/adaptive");
const types_1 = require("../src/core/types");
const catalog_1 = require("../src/core/catalog");
const time_1 = require("../src/core/time");
const rewards_1 = require("../src/core/rewards");
for (const age of ['3-5', '6-8', '9-12']) {
    for (const id of types_1.GAME_IDS) {
        (0, node_test_1.test)(`${id} ${age}: 250 deterministic valid generated puzzles with correct solutions`, () => {
            const { min, max } = catalog_1.AGE_BOUNDS[age];
            const unique = new Set();
            for (let seed = 0; seed < 250; seed++) {
                const level = min + (seed % (max - min + 1));
                const c = (0, generate_1.generateChallenge)(id, age, level, seed);
                strict_1.default.ok((0, generate_1.validateChallenge)(c), JSON.stringify(c));
                strict_1.default.deepEqual((0, generate_1.generateChallenge)(id, age, level, seed), c);
                if (c.mode === 'cards') {
                    const groups = new Map();
                    c.board.forEach((token, index) => groups.set(token, [...(groups.get(token) || []), index]));
                    const matching = [...groups.values()].flat();
                    strict_1.default.ok((0, generate_1.evaluateCardSolution)(c, matching));
                    strict_1.default.ok((0, generate_1.evaluateChallenge)(c, matching.map(x => `index:${x}`)));
                    strict_1.default.equal((0, generate_1.evaluateCardSolution)(c, [...matching].reverse().slice(1)), false);
                    strict_1.default.equal((0, generate_1.isMatchingCardPair)(c, 0, 0), false);
                    strict_1.default.equal((0, generate_1.isMatchingCardPair)(c, 0, 999), false);
                    strict_1.default.equal((0, generate_1.evaluateChallenge)(c, c.answer), false);
                }
                else
                    strict_1.default.ok((0, generate_1.evaluateChallenge)(c, c.answer));
                unique.add(JSON.stringify(c));
                if (c.mode === 'route' || c.mode === 'maze') {
                    for (let i = 0; i < c.answer.length; i++)
                        strict_1.default.equal((0, generate_1.allowedNextCell)(c, c.answer.slice(0, i), c.answer[i]), true);
                }
                if (c.mode !== 'cards') {
                    const wrong = c.mode === 'multi' ? [] : c.answer.slice(0, -1);
                    strict_1.default.equal((0, generate_1.evaluateChallenge)(c, wrong), false);
                }
            }
            strict_1.default.ok(unique.size > 180, `Insufficient variation for ${id}/${age}: ${unique.size}`);
        });
    }
    (0, node_test_1.test)(`adaptive bounded, deterministic: ${age}`, () => {
        let d = (0, adaptive_1.initialDifficulty)(age);
        const min = catalog_1.AGE_BOUNDS[age].min;
        const max = catalog_1.AGE_BOUNDS[age].max;
        for (let i = 0; i < 100; i++)
            d = (0, adaptive_1.nextDifficulty)(age, d, { success: true, hints: 0, mistakes: 0 });
        strict_1.default.equal(d.level, max);
        for (let i = 0; i < 100; i++)
            d = (0, adaptive_1.nextDifficulty)(age, d, { success: false, hints: 1, mistakes: 3 });
        strict_1.default.equal(d.level, min);
        d = (0, adaptive_1.initialDifficulty)(age);
        for (let i = 0; i < 10; i++)
            d = (0, adaptive_1.nextDifficulty)(age, d, { success: true, hints: 1, mistakes: 0 });
        strict_1.default.equal(d.level, min);
    });
}
(0, node_test_1.test)('usage bounds and limits, no negative usage', () => {
    strict_1.default.equal((0, time_1.heartbeatDelta)(1000, 6300), 5);
    strict_1.default.equal((0, time_1.heartbeatDelta)(9000, 1000), 0);
    strict_1.default.equal((0, time_1.canPlay)({ profileUsed: 899, householdUsed: 899, sessionUsed: 100, dailyLimitMin: 15, householdLimitMin: 20, sessionLimitMin: 5, paused: false }), true);
    strict_1.default.equal((0, time_1.canPlay)({ profileUsed: 900, householdUsed: 0, sessionUsed: 0, dailyLimitMin: 15, householdLimitMin: 20, sessionLimitMin: 5, paused: false }), false);
    strict_1.default.equal((0, time_1.canPlay)({ profileUsed: 0, householdUsed: 1200, sessionUsed: 0, dailyLimitMin: 15, householdLimitMin: 20, sessionLimitMin: 5, paused: false }), false);
    strict_1.default.equal((0, time_1.canPlay)({ profileUsed: 0, householdUsed: 0, sessionUsed: 300, dailyLimitMin: 15, householdLimitMin: 20, sessionLimitMin: 5, paused: false }), false);
    strict_1.default.equal((0, time_1.canPlay)({ profileUsed: 0, householdUsed: 0, sessionUsed: 0, dailyLimitMin: 15, householdLimitMin: 20, sessionLimitMin: 5, paused: true }), false);
    strict_1.default.match((0, time_1.dayKey)(Date.now()), /^\d{4}-\d{2}-\d{2}$/);
});
(0, node_test_1.test)('reward requirements deterministic, no unintended awards', () => {
    strict_1.default.deepEqual((0, rewards_1.earnedBadges)(0, 0), []);
    strict_1.default.deepEqual((0, rewards_1.earnedBadges)(1, 1), ['first_adventure']);
    strict_1.default.deepEqual((0, rewards_1.earnedBadges)(5, 4), ['first_adventure', 'curious_explorer', 'world_wanderer']);
    strict_1.default.equal(new Set((0, rewards_1.earnedBadges)(100, 12)).size, 4);
});
(0, node_test_1.test)('Play-hour boundaries work and support crossing midnight', () => {
    const today = new Date(2026, 10, 14, 9, 30).getTime();
    const night = new Date(2026, 10, 14, 23, 30).getTime();
    strict_1.default.equal((0, time_1.withinAllowedHours)('07:00', '20:00', today), true);
    strict_1.default.equal((0, time_1.withinAllowedHours)('07:00', '20:00', night), false);
    strict_1.default.equal((0, time_1.withinAllowedHours)('21:00', '02:00', night), true);
    strict_1.default.equal((0, time_1.withinAllowedHours)('21:00', '02:00', today), false);
    strict_1.default.equal((0, time_1.withinAllowedHours)('00:00', '00:00', night), true);
    strict_1.default.equal((0, time_1.withinAllowedHours)('99:00', '20:00', night), false);
});
