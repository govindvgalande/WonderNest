"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const parentGate_1 = require("../src/security/parentGate");
const DeviceAuth = __importStar(require("expo-local-authentication"));
const SecureStore = __importStar(require("expo-secure-store"));
(0, node_test_1.test)('parent gate: six digits, correct/wrong unlock, persisted lockout, device recovery', async () => {
    await (0, parentGate_1.clearParentCredentials)();
    strict_1.default.equal(await (0, parentGate_1.hasParentPin)(), false);
    await strict_1.default.rejects(() => (0, parentGate_1.setupParentPin)('12'));
    await strict_1.default.rejects(() => (0, parentGate_1.setupParentPin)('abc123'));
    await (0, parentGate_1.setupParentPin)('123456');
    strict_1.default.equal(await (0, parentGate_1.hasParentPin)(), true);
    await strict_1.default.rejects(() => (0, parentGate_1.setupParentPin)('888888'));
    strict_1.default.equal((await (0, parentGate_1.verifyParentPin)('123457')).ok, false);
    strict_1.default.equal((await (0, parentGate_1.verifyParentPin)('123456')).ok, true);
    for (let i = 0; i < 4; i++)
        strict_1.default.equal((await (0, parentGate_1.verifyParentPin)('000000')).ok, false);
    const fifth = await (0, parentGate_1.verifyParentPin)('000000');
    strict_1.default.ok(fifth.lockedSeconds >= 30);
    const saved = await SecureStore.getItemAsync('wondernest.parent.lock');
    strict_1.default.ok(Number(saved) > Date.now());
    strict_1.default.equal((await (0, parentGate_1.verifyParentPin)('123456')).ok, false);
    // Recovery explicitly requires successful device authentication.
    DeviceAuth.__setAuth(false);
    strict_1.default.equal(await (0, parentGate_1.recoverParentPinUsingDeviceLock)('654321'), false);
    DeviceAuth.__setAuth(true);
    strict_1.default.equal(await (0, parentGate_1.recoverParentPinUsingDeviceLock)('654321'), true);
    strict_1.default.equal((await (0, parentGate_1.verifyParentPin)('654321')).ok, true);
    strict_1.default.equal((await (0, parentGate_1.verifyParentPin)('123456')).ok, false);
});
