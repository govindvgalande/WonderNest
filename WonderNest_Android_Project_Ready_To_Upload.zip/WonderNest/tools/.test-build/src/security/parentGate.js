"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.hasParentPin = hasParentPin;
exports.setupParentPin = setupParentPin;
exports.verifyParentPin = verifyParentPin;
exports.recoverParentPinUsingDeviceLock = recoverParentPinUsingDeviceLock;
exports.clearParentCredentials = clearParentCredentials;
const SecureStore = __importStar(require("expo-secure-store"));
const Crypto = __importStar(require("expo-crypto"));
const LocalAuthentication = __importStar(require("expo-local-authentication"));
const KEY = 'wondernest.parent.sha256';
const SALT = 'wondernest.parent.salt';
const FAIL = 'wondernest.parent.fail';
const LOCK = 'wondernest.parent.lock';
const secure = { get: (k) => SecureStore.getItemAsync(k), set: (k, v) => SecureStore.setItemAsync(k, v), del: (k) => SecureStore.deleteItemAsync(k) };
async function hasParentPin() { return !!(await secure.get(KEY)); }
function isValid(pin) { return /^\d{6,12}$/.test(pin); }
async function hash(pin, salt) { return Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, `wondernest-v1:${salt}:${pin}`); }
async function setupParentPin(pin) {
    if (!isValid(pin))
        throw new Error('PIN must be 6–12 digits');
    if (await hasParentPin())
        throw new Error('Parent PIN already exists');
    const salt = Crypto.randomUUID();
    await secure.set(SALT, salt);
    await secure.set(KEY, await hash(pin, salt));
    await secure.set(FAIL, '0');
    await secure.set(LOCK, '0');
}
async function verifyParentPin(pin) {
    const lockedUntil = Number(await secure.get(LOCK) || '0');
    if (Date.now() < lockedUntil)
        return { ok: false, lockedSeconds: Math.ceil((lockedUntil - Date.now()) / 1000) };
    const saved = await secure.get(KEY);
    const salt = await secure.get(SALT);
    if (!saved || !salt)
        return { ok: false, lockedSeconds: 0 };
    const candidate = await hash(pin, salt);
    // Constant work for matching digests; SECURE STORE provides device-backed at-rest encryption.
    let diff = 0;
    for (let i = 0; i < Math.max(candidate.length, saved.length); i++)
        diff |= (candidate.charCodeAt(i) || 0) ^ (saved.charCodeAt(i) || 0);
    if (diff === 0) {
        await secure.set(FAIL, '0');
        await secure.set(LOCK, '0');
        return { ok: true, lockedSeconds: 0 };
    }
    const failures = Number(await secure.get(FAIL) || '0') + 1;
    await secure.set(FAIL, String(failures));
    const lockMs = failures >= 5 ? Math.min(3600000, 30000 * Math.pow(2, Math.min(8, failures - 5))) : 0;
    if (lockMs)
        await secure.set(LOCK, String(Date.now() + lockMs));
    return { ok: false, lockedSeconds: lockMs / 1000 };
}
/** Uses Android OS credential/biometric. If unavailable, clearing app data is the only recovery. */
async function recoverParentPinUsingDeviceLock(newPin) {
    if (!isValid(newPin))
        throw new Error('PIN must be 6–12 digits');
    const enrolled = await LocalAuthentication.isEnrolledAsync();
    if (!enrolled)
        return false;
    const auth = await LocalAuthentication.authenticateAsync({ promptMessage: 'Parent PIN recovery', disableDeviceFallback: false });
    if (!auth.success)
        return false;
    await secure.del(KEY);
    await secure.del(SALT);
    await secure.del(FAIL);
    await secure.del(LOCK);
    await setupParentPin(newPin);
    return true;
}
/** Only call after successful authenticated parent action. */
async function clearParentCredentials() { for (const k of [KEY, SALT, FAIL, LOCK])
    await secure.del(k); }
