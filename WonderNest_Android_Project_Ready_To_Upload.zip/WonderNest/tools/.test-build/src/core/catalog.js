"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TOKEN_ICONS = exports.AGE_BOUNDS = exports.GAME_INFO = exports.PLACES = exports.NOTES = exports.SHAPES = exports.OBJECTS = void 0;
exports.OBJECTS = [
    'fox', 'owl', 'panda', 'rabbit', 'elephant', 'cat', 'dog', 'fish', 'butterfly', 'frog', 'bear', 'bee',
    'apple', 'banana', 'grape', 'orange', 'pear', 'cherry', 'carrot', 'strawberry',
    'car', 'train', 'plane', 'boat', 'bicycle', 'bus', 'rocket', 'truck',
    'star', 'sun', 'moon', 'cloud', 'rainbow', 'flower', 'tree', 'mushroom'
];
exports.SHAPES = ['red_circle', 'blue_square', 'yellow_star', 'green_triangle', 'purple_heart', 'orange_diamond'];
exports.NOTES = ['bell', 'drum', 'flute', 'chime', 'harp', 'wood'];
exports.PLACES = ['tree', 'house', 'pond', 'bridge', 'hill', 'garden'];
exports.GAME_INFO = {
    cards: { icon: '🃏', world: 'forest', skills: ['visualMemory'] },
    objects: { icon: '🧺', world: 'forest', skills: ['recall'] },
    pattern: { icon: '🌈', world: 'rainbow', skills: ['sequence'] },
    missing: { icon: '🔎', world: 'forest', skills: ['observation'] },
    treasure: { icon: '🗺️', world: 'treasure', skills: ['spatial'] },
    sounds: { icon: '🎶', world: 'rainbow', skills: ['auditory'] },
    detective: { icon: '🕵️', world: 'castle', skills: ['observation'] },
    story: { icon: '📖', world: 'castle', skills: ['recall'] },
    shapes: { icon: '🔶', world: 'rainbow', skills: ['sequence'] },
    order: { icon: '🔢', world: 'mountain', skills: ['workingMemory'] },
    maze: { icon: '🏰', world: 'treasure', skills: ['spatial'] },
    explorer: { icon: '🚀', world: 'mountain', skills: ['reasoning'] }
};
exports.AGE_BOUNDS = {
    '3-5': { min: 1, max: 3, session: 8, daily: 15 },
    '6-8': { min: 2, max: 6, session: 12, daily: 20 },
    '9-12': { min: 3, max: 9, session: 15, daily: 25 }
};
exports.TOKEN_ICONS = {
    fox: '🦊', owl: '🦉', panda: '🐼', rabbit: '🐰', elephant: '🐘', cat: '🐱', dog: '🐶', fish: '🐟', butterfly: '🦋', frog: '🐸', bear: '🐻', bee: '🐝', apple: '🍎', banana: '🍌', grape: '🍇', orange: '🍊', pear: '🍐', cherry: '🍒', carrot: '🥕', strawberry: '🍓', car: '🚗', train: '🚂', plane: '✈️', boat: '⛵', bicycle: '🚲', bus: '🚌', rocket: '🚀', truck: '🚚', star: '⭐', sun: '☀️', moon: '🌙', cloud: '☁️', rainbow: '🌈', flower: '🌻', tree: '🌳', mushroom: '🍄', red_circle: '🔴', blue_square: '🟦', yellow_star: '🌟', green_triangle: '🔺', purple_heart: '💜', orange_diamond: '🔶', bell: '🔔', drum: '🥁', flute: '🎵', chime: '✨', harp: '🎼', wood: '🪵', house: '🏠', pond: '💧', bridge: '🌉', hill: '⛰️', garden: '🌷'
};
