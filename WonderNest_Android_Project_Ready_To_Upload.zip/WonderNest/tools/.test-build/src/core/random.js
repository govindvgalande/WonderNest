"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.random = random;
exports.shuffle = shuffle;
exports.sample = sample;
exports.pick = pick;
/** Deterministic, dependency-free seeded PRNG. No Math.random in puzzle generation. */
function random(seed) {
    let a = seed >>> 0;
    return () => {
        a = (a + 0x6D2B79F5) | 0;
        let t = Math.imul(a ^ (a >>> 15), 1 | a);
        t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}
function shuffle(data, rng) {
    const copy = [...data];
    for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(rng() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
}
function sample(data, count, rng) {
    if (count > data.length || count < 0)
        throw new Error('Invalid sample size');
    return shuffle(data, rng).slice(0, count);
}
function pick(data, rng) {
    if (!data.length)
        throw new Error('Empty choice');
    return data[Math.floor(rng() * data.length)];
}
