"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GAME_IDS = void 0;
exports.GAME_IDS = ['cards', 'objects', 'pattern', 'missing', 'treasure', 'sounds', 'detective', 'story', 'shapes', 'order', 'maze', 'explorer'];
